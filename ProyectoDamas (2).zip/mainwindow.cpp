#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), ui(new Ui::MainWindow) {
    ui->setupUi(this);

    tablero = new Tablero(this);
    ui->LayoutTablero->addWidget(tablero);

    connect(tablero, &Tablero::actualizarContadores, this, &MainWindow::actualizarContadores);
    connect(tablero, &Tablero::juegoFinalizado, this, &MainWindow::mostrarGanador);

    actualizarContadores();
}

MainWindow::~MainWindow() {
    delete ui;
}

void MainWindow::actualizarContadores() {
    int blancas, negras;
    tablero->contarFichas(blancas, negras);
    ui->lblBlancas->setText(QString::number(blancas));
    ui->lblNegras->setText(QString::number(negras));
}

void MainWindow::mostrarGanador(QString ganador) {
    QMessageBox::information(this, "Fin del juego", ganador + " ha ganado la partida.");
}

void MainWindow::on_btnIniciar_clicked() {
    tablero->reiniciar();
    actualizarContadores();
}

void MainWindow::on_btnReiniciar_clicked() {
    tablero->reiniciar();
    actualizarContadores();
}

void MainWindow::on_btnSalir_clicked() {
    close();
}
