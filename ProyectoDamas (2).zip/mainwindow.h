#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "tablero.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void actualizarContadores();
    void mostrarGanador(QString ganador);
    void on_btnIniciar_clicked();
    void on_btnReiniciar_clicked();
    void on_btnSalir_clicked();

private:
    Ui::MainWindow *ui;
    Tablero *tablero;
};

#endif // MAINWINDOW_H
