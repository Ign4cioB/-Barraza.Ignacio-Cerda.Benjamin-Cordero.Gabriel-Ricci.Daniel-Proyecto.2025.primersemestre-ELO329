#ifndef FICHA_H
#define FICHA_H

enum class Ficha {
    Ninguna,
    Blanca,
    Negra,
    ReinaBlanca,
    ReinaNegra
};

#endif // FICHA_H
