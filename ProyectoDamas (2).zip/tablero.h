#ifndef TABLERO_H
#define TABLERO_H

#include <QWidget>
#include <QMessageBox>
#include "ficha.h"  // 👈 Incluimos el enum desde el nuevo archivo

class Tablero : public QWidget
{
    Q_OBJECT

public:
    explicit Tablero(QWidget *parent = nullptr);
    QSize sizeHint() const override;
    void reiniciar();
    void contarFichas(int &blancas, int &negras);
    bool juegoTerminado() const;

signals:
    void actualizarContadores();
    void juegoFinalizado(QString ganador);

protected:
    void paintEvent(QPaintEvent *event) override;
    void mousePressEvent(QMouseEvent *event) override;

private:
    Ficha tablero[8][8];     //uso del enum ficha
    int seleccionX, seleccionY;
    bool turnoBlanco;
    QVector<QPair<int, int>> movimientosPermitidos;
    QVector<QPair<int, int>> fichasObligadas;
    QList<QPair<int, int>> fichasCapturables;
    bool hayFichaSeleccionada(int x, int y) const;
    bool esMovimientoValido(int x1, int y1, int x2, int y2) const;
    void moverFicha(int x1, int y1, int x2, int y2);
    bool puedeComer(int x, int y) const;
    void coronarSiEsNecesario(int x, int y);
    bool CapturaDisponible(int x, int y) const;
    void calcularMovimientos(int x, int y);
    void marcarFichasCapturables(int x, int y);
    std::vector<std::pair<int, int>> fichasQuePuedenCapturar(bool blancas) const;
};

#endif // TABLERO_H
