#include "tablero.h"
#include <QPainter>
#include <QMouseEvent>
#include <QDebug>

Tablero::Tablero(QWidget *parent)
    : QWidget(parent)
{
    reiniciar();            // resetea el tablero
}

QSize Tablero::sizeHint() const {
    return QSize(400, 400);  // tamaño  tablero
}

void Tablero::reiniciar() { //metodo que resetea
    for (int y = 0; y < 8; ++y) {
        for (int x = 0; x < 8; ++x) {
            tablero[y][x] = Ficha::Ninguna;  //limpia
            if ((x + y) % 2 == 1) {
                if (y < 3)
                    tablero[y][x] = Ficha::Negra;   // coloca las fichas negras
                else if (y > 4)
                    tablero[y][x] = Ficha::Blanca;  // coloca las fichas blancas
            }
        }
    }
    seleccionX = seleccionY = -1;  // Sin ficha seleccionada
    turnoBlanco = true;            // empieza el jugador blanco
    emit actualizarContadores();     // actualizar contadores
    update();                      // redibuja el tablero
}

// Pinta el tablero y las fichas
void Tablero::paintEvent(QPaintEvent *) {
    QPainter painter(this);
    int w = width() / 8;
    int h = height() / 8;

    for (int y = 0; y < 8; ++y) {
        for (int x = 0; x < 8; ++x) {
            QColor color = (x + y) % 2 == 0 ? Qt::white : Qt::gray;
            painter.fillRect(x * w, y * h, w, h, color);
            for(const QPair<int, int>& p : fichasObligadas){
                if(x==p.first && y==p.second) painter.fillRect(x*w, y*h, w, h, QColor(255, 165, 0, 120));
            }
            for(const QPair<int, int>& d : movimientosPermitidos){
                if(x==d.first && y==d.second) painter.fillRect(x*w, y*h, w, h, QColor(0, 255, 0, 100));
            }
            for(const QPair<int, int>& c : fichasCapturables){
                if(x==c.first && y==c.second) painter.fillRect(x*w, y*h, w, h, QColor(255, 0, 0, 120));
            }
            if (x == seleccionX && y == seleccionY)
                painter.fillRect(x * w, y * h, w, h, Qt::yellow);  // casilla seleccionada

            Ficha ficha = tablero[y][x];
            if (ficha != Ficha::Ninguna) {
                painter.setBrush(ficha == Ficha::Blanca || ficha == Ficha::ReinaBlanca ? Qt::white : Qt::black);
                painter.setPen(Qt::black);
                painter.drawEllipse(x * w + w / 8, y * h + h / 8, 3 * w / 4, 3 * h / 4);

                if (ficha == Ficha::ReinaBlanca || ficha == Ficha::ReinaNegra) {
                    painter.setPen(Qt::red);
                    painter.drawText(x * w + w / 2 - 5, y * h + h / 2 + 5, "R");  // Letra R para Reina
                }
            }
        }
    }
}

// uso del click/mouse
void Tablero::mousePressEvent(QMouseEvent *event) {
    int w = width() / 8;
    int h = height() / 8;
    int x = event->pos().x() / w;
    int y = event->pos().y() / h;
    auto capturables=fichasQuePuedenCapturar(turnoBlanco);
    fichasObligadas.clear();
    for(const auto &f: capturables) fichasObligadas.append(QPair<int, int>(f.first, f.second));
    fichasCapturables.clear();
    if (seleccionX == -1){
        if(!capturables.empty()){
            for(const auto &ficha : capturables){
                if(x==ficha.first && y==ficha.second){
                    seleccionX=x;
                    seleccionY=y;
                    calcularMovimientos(x, y);
                    marcarFichasCapturables(x, y);
                    break;
                }
            }
        }else{
            if(hayFichaSeleccionada(x, y)){
                seleccionX=x;
                seleccionY=y;
                calcularMovimientos(x, y);
            }
        }
    }else{
        movimientosPermitidos.clear();
        bool permitidoMover=true;
        bool esCaptura=false;
        if(!capturables.empty()){
            permitidoMover=false;
            for(const auto &ficha : capturables){
                if(seleccionX==ficha.first && seleccionY==ficha.second){
                    permitidoMover=true;
                    break;
                }
            }
        }
        if(permitidoMover && esMovimientoValido(seleccionX, seleccionY, x, y)){
            esCaptura=(abs(x-seleccionX)>=2);
            if(!capturables.empty() && !esCaptura){
                seleccionX=seleccionY=-1;
                fichasCapturables.clear();
            }else{
                moverFicha(seleccionX, seleccionY, x, y);
                coronarSiEsNecesario(x, y);
                fichasCapturables.clear();
                if(esCaptura && CapturaDisponible(x, y)){
                    seleccionX=x;
                    seleccionY=y;
                    calcularMovimientos(x, y);
                    marcarFichasCapturables(x, y);
                    fichasObligadas.clear();
                    fichasObligadas.append(QPair<int, int>(x, y));
                }else{
                    turnoBlanco=!turnoBlanco;
                    seleccionX=seleccionY=-1;
                    fichasObligadas.clear();
                }
                emit actualizarContadores();
            }
        }else{
            seleccionX=seleccionY=-1;
            fichasCapturables.clear();
        }
    }

    update();  // Redibuja tablero
    if (juegoTerminado()) {
        QString ganador = turnoBlanco ? "Negras" : "Blancas";
        QMessageBox::information(this, "Fin del juego", "¡Ganaron las " + ganador + "!");
    }
}

// Verifica si hay una ficha seleccionable
bool Tablero::hayFichaSeleccionada(int x, int y) const {
    Ficha ficha = tablero[y][x];
    if (ficha == Ficha::Ninguna) return false;
    if (turnoBlanco)
        return ficha == Ficha::Blanca || ficha == Ficha::ReinaBlanca;
    else
        return ficha == Ficha::Negra || ficha == Ficha::ReinaNegra;
}

// verificar si un movimiento es legal
bool Tablero::esMovimientoValido(int x1, int y1, int x2, int y2) const {
    Ficha ficha = tablero[y1][x1];
    if (tablero[y2][x2] != Ficha::Ninguna)
        return false;

    int dx = x2 - x1;
    int dy = y2 - y1;

    if (abs(dx) == 1 && ((ficha == Ficha::Blanca && dy == -1) ||
                         (ficha == Ficha::Negra && dy == 1)))
        return true;

    if (abs(dx) == 2 && abs(dy) == 2) {
        int mx = x1 + dx / 2;
        int my = y1 + dy / 2;
        Ficha intermedia = tablero[my][mx];
        if(ficha==Ficha::Blanca){
            if(dy==-2 && (intermedia==Ficha::Negra || intermedia==Ficha::ReinaNegra)) return true;
        }
        else if(ficha==Ficha::Negra){
            if(dy==2 && (intermedia==Ficha::Blanca || intermedia==Ficha::ReinaBlanca)) return true;
        }
    }
    if(ficha==Ficha::ReinaBlanca || ficha==Ficha::ReinaNegra){
        if(abs(dx)!=abs(dy) || dx==0) return false;
        int pasoX=dx>0 ? 1 : -1;
        int pasoY=dy>0 ? 1 : -1;
        int x=x1+pasoX;
        int y=y1+pasoY;
        int piezasAlPaso=0;
        Ficha rival1=(ficha==Ficha::ReinaBlanca) ? Ficha::Negra : Ficha::Blanca;
        Ficha rival2=(ficha==Ficha::ReinaBlanca) ? Ficha::ReinaNegra : Ficha::ReinaBlanca;
        while(x!=x2 && y!=y2){
            if(tablero[y][x]!=Ficha::Ninguna){
                if((tablero[y][x]==rival1 || tablero[y][x]==rival2) && piezasAlPaso==0){
                    piezasAlPaso++;
                }else return false;
            }
            x+=pasoX;
            y+=pasoY;
        }
        if(piezasAlPaso==0) return true;
        if(piezasAlPaso==1) return true;
    }
    return false;
}

//movimiento de una ficha
void Tablero::moverFicha(int x1, int y1, int x2, int y2) {
    Ficha ficha = tablero[y1][x1];
    tablero[y1][x1] = Ficha::Ninguna;
    tablero[y2][x2] = ficha;

    if (abs(x2 - x1) == 2) {
        int mx = (x1 + x2) / 2;
        int my = (y1 + y2) / 2;
        tablero[my][mx] = Ficha::Ninguna;  // Captura
    }
    if((ficha==Ficha::ReinaBlanca || ficha==Ficha::ReinaNegra) && abs(x2-x1)>2){
        int dx=(x2-x1)>0 ? 1 : -1;
        int dy=(y2-y1)>0 ? 1 : -1;
        int x=x1+dx;
        int y=y1+dy;
        Ficha rival1=(ficha==Ficha::ReinaBlanca) ? Ficha::Negra : Ficha::Blanca;
        Ficha rival2=(ficha==Ficha::ReinaBlanca) ? Ficha::ReinaNegra : Ficha::ReinaBlanca;
        while(x!=x2 && y!=y2){
            if(tablero[y][x]==rival1 || tablero[y][x]==rival2){
                tablero[y][x]=Ficha::Ninguna;
                break;
            }
            x+=dx;
            y+=dy;
        }
    }
}

// corona fichas al llegar al borde opuesto
void Tablero::coronarSiEsNecesario(int x, int y) {
    Ficha &ficha = tablero[y][x];
    if (ficha == Ficha::Blanca && y == 0)
        ficha = Ficha::ReinaBlanca;
    else if (ficha == Ficha::Negra && y == 7)
        ficha = Ficha::ReinaNegra;
}

// contar fichas resultante
void Tablero::contarFichas(int &blancas, int &negras) {
    blancas = negras = 0;
    for (int y = 0; y < 8; ++y) {
        for (int x = 0; x < 8; ++x) {
            if (tablero[y][x] == Ficha::Blanca || tablero[y][x] == Ficha::ReinaBlanca)
                blancas++;
            else if (tablero[y][x] == Ficha::Negra || tablero[y][x] == Ficha::ReinaNegra)
                negras++;
        }
    }
}

// verificar si el juego ha terminado
bool Tablero::juegoTerminado() const {
    int blancas = 0, negras = 0;
    for (int y = 0; y < 8; ++y) {
        for (int x = 0; x < 8; ++x) {
            if (tablero[y][x] == Ficha::Blanca || tablero[y][x] == Ficha::ReinaBlanca)
                blancas++;
            else if (tablero[y][x] == Ficha::Negra || tablero[y][x] == Ficha::ReinaNegra)
                negras++;
        }
    }
    return blancas == 0 || negras == 0;
}

bool Tablero::CapturaDisponible(int x, int y) const{
    Ficha ficha=tablero[y][x];
    if(ficha==Ficha::Blanca || ficha==Ficha::Negra){
        int dir=(ficha==Ficha::Blanca) ? -1 : 1;
        for(int dx=-2; dx<=2; dx+=4){
            int nx=x+dx;
            int ny=y+dir*2;
            if(nx>=0 && nx<8 && ny>=0 && ny<8){
                if(esMovimientoValido(x, y, nx, ny)) return true;
            }
        }
    }
    if(ficha==Ficha::ReinaBlanca || ficha==Ficha::ReinaNegra){
        for(int dx=-1; dx<=1; dx+=2){
            for(int dy=-1; dy<=1; dy+=2){
                int tx=x+dx;
                int ty=y+dy;
                while(tx>=0 && tx<8 && ty>=0 && ty<8){
                    if(tablero[ty][tx]!=Ficha::Ninguna){
                        int saltoX=tx+dx, saltoY=ty+dy;
                        while(saltoX>=0 && saltoX<8 && saltoY>=0 && saltoY<8){
                            if(tablero[saltoY][saltoX]==Ficha::Ninguna){
                                if(esMovimientoValido(x, y, saltoX, saltoY)) return true;
                            }else break;
                            saltoX+=dx;
                            saltoY+=dy;
                        }
                        break;
                    }
                    tx+=dx;
                    ty+=dy;
                }
            }
        }
    }
    return false;
}

std::vector<std::pair<int, int>> Tablero::fichasQuePuedenCapturar(bool blancas) const{
    std::vector<std::pair<int, int>> resultado;
    for(int y=0; y<8; ++y){
        for(int x=0; x<8; ++x){
            Ficha ficha=tablero[y][x];
            if(blancas){
                if(ficha==Ficha::Blanca || ficha==Ficha::ReinaBlanca){
                    if(CapturaDisponible(x, y)) resultado.push_back({x, y});
                }
            }else{
                if(ficha==Ficha::Negra || ficha==Ficha::ReinaNegra){
                    if(CapturaDisponible(x, y)) resultado.push_back({x, y});
                }
            }
        }
    }
    return resultado;
}

void Tablero::calcularMovimientos(int x, int y){
    movimientosPermitidos.clear();
    Ficha ficha=tablero[y][x];
    if(ficha==Ficha::Blanca || ficha==Ficha::Negra){
        int dir=(ficha==Ficha::Blanca) ? -1 : 1;
        for(int dx=-2; dx<=2; dx+=4){
            int nx=x+dx;
            int ny=y+dir*2;
            if(nx>=0 && nx<8 && ny>=0 && ny<8){
                if(esMovimientoValido(x, y, nx, ny)) movimientosPermitidos.append(QPair<int, int>(nx, ny));
            }
        }
        if(fichasObligadas.isEmpty()){
            for(int dx=-1; dx<=1; dx+=2){
                int nx=x+dx;
                int ny=y+dir;
                if(nx>=0 && nx<8 && ny>=0 && ny<8){
                    if(esMovimientoValido(x, y, nx, ny)) movimientosPermitidos.append(QPair<int, int>(nx, ny));
                }
            }
        }
    }else if(ficha==Ficha::ReinaBlanca || ficha==Ficha::ReinaNegra){
        bool capturaDisponible=CapturaDisponible(x, y);
        for(int dx=-1; dx<=1; dx+=2){
            for(int dy=-1; dy<=1; dy+=2){
                int tx=x+dx;
                int ty=y+dy;
                bool fichaEncontrada=false;
                while(tx>=0 && tx<8 && ty>=0 && ty<8){
                    if(tablero[ty][tx]!=Ficha::Ninguna){
                        Ficha rival1=(ficha==Ficha::ReinaBlanca) ? Ficha::Negra : Ficha::Blanca;
                        Ficha rival2=(ficha==Ficha::ReinaBlanca) ? Ficha::ReinaNegra : Ficha::ReinaBlanca;
                        if((tablero[ty][tx]==rival1 || tablero[ty][tx]==rival2) && !fichaEncontrada){
                            fichaEncontrada=true;
                        }else break;
                    }else if(fichaEncontrada) movimientosPermitidos.append(QPair<int, int>(tx, ty));
                    else if(!capturaDisponible && !fichasObligadas.isEmpty()) movimientosPermitidos.append(QPair<int, int>(tx, ty));
                    tx+=dx;
                    ty+=dy;
                }
            }
        }
    }
}

void Tablero::marcarFichasCapturables(int x, int y){
    fichasCapturables.clear();
    Ficha ficha=tablero[y][x];
    if(ficha==Ficha::Blanca || ficha==Ficha::Negra){
        int dir=(ficha==Ficha::Blanca) ? -1 : 1;
        for(int dx=-2; dx<=2; dx+=4){
            int nx=x+dx;
            int ny=y+dir*2;
            if(nx>=0 && nx<8 && ny>=0 && ny<8){
                if(esMovimientoValido(x, y, nx, ny)){
                    int mx=x+dx/2;
                    int my=y+dir;
                    fichasCapturables.append(QPair<int, int>(mx, my));
                }
            }
        }
    }else if(ficha==Ficha::ReinaBlanca || ficha==Ficha::ReinaNegra){
        for(int dx=-1; dx<=1; dx+=2){
            for(int dy=-1; dy<=1; dy+=2){
                int tx=x+dx;
                int ty=y+dy;
                bool fichaEncontrada=false;
                int fx=-1, fy= -1;
                while(tx>=0 && tx<8 && ty>=0 && ty<8){
                    if(tablero[ty][tx]!=Ficha::Ninguna){
                        Ficha rival1=(ficha==Ficha::ReinaBlanca) ? Ficha::Negra : Ficha::Blanca;
                        Ficha rival2=(ficha==Ficha::ReinaBlanca) ? Ficha::ReinaNegra : Ficha::ReinaBlanca;
                        if((tablero[ty][tx]==rival1 || tablero[ty][tx]==rival2) && !fichaEncontrada){
                            fichaEncontrada=true;
                            fx=tx;
                            fy=ty;
                        }else break;
                    }else if(fichaEncontrada){
                        fichasCapturables.append(QPair<int, int>(fx, fy));
                        break;
                    }
                    tx+=dx;
                    ty+=dy;
                }
            }
        }
    }
}
